import { Outlet } from "react-router-dom";

export default function Search() {
  return <Outlet></Outlet>;
}

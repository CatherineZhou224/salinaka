const addToCarts = "addToCarts";
const removeFromCarts = "removeFromCarts";
const increaseQuantByOne = "increaseQuantByOne";
const decreaseQuantByOne = "decreaseQuantByOne";
const clearAllItems = "clearAllItems";
export {
  addToCarts,
  removeFromCarts,
  increaseQuantByOne,
  decreaseQuantByOne,
  clearAllItems,
};

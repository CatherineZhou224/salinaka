import { Outlet } from "react-router-dom";

export default function Product() {
  return <Outlet></Outlet>;
}
